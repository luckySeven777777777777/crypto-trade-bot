import express from "express";
import bodyParser from "body-parser";
import axios from "axios";

const app = express();
app.use(bodyParser.json());

// === 从 Railway 变量读取机器人 Token ===
const TOKEN = process.env.BOT_TOKEN;
const TELEGRAM_API = `https://api.telegram.org/bot${TOKEN}`;

// === 根目录测试页面（防白屏） ===
app.get("/", (req, res) => {
  res.send("Webhook active. Server running.");
});

// ======================================================
// Telegram Webhook 接收区
// ======================================================
app.post("/webhook", async (req, res) => {
  try {
    const update = req.body;
    console.log("Webhook received:", JSON.stringify(update, null, 2));

    // ==================================================
    // 处理按钮点击 callback_query
    // ==================================================
    if (update.callback_query) {
      const cb = update.callback_query;
      const chatId = cb.message.chat.id;
      const messageId = cb.message.message_id;

      const username =
        cb.from.username
          ? "@" + cb.from.username
          : cb.from.first_name || "Unknown User";

      const now = new Date().toLocaleString();

      // 用户按下的按钮
      let resultText = "";
      if (cb.data === "trade_success") {
        resultText = `✔ 交易已确认\n操作人：${username}\n时间：${now}`;
      } else {
        resultText = `✖ 交易已取消\n操作人：${username}\n时间：${now}`;
      }

      // 1）移除原有按钮
      await axios.post(`${TELEGRAM_API}/editMessageReplyMarkup`, {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: { inline_keyboard: [] }
      });

      // 2）发送处理结果
      await axios.post(`${TELEGRAM_API}/sendMessage`, {
        chat_id: chatId,
        text: resultText
      });
    }

    // 一定要返回 200 给 Telegram
    res.sendStatus(200);

  } catch (err) {
    console.error("Webhook error:", err.message);
    res.sendStatus(200); // 返回 200 避免 Telegram 取消 webhook
  }
});

// ======================================================
// 启动端口
// ======================================================
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log("Server running on port", PORT);
});
