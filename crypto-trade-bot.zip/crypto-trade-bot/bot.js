// bot.js
import express from "express";
import axios from "axios";

const router = express.Router();

const TOKEN = process.env.BOT_TOKEN;
const API = `https://api.telegram.org/bot${TOKEN}`;

// 处理 Webhook 回调
router.post("/", async (req, res) => {
    console.log("Webhook received:", JSON.stringify(req.body, null, 2));

    const update = req.body;

    if (update.callback_query) {
        const q = update.callback_query;
        const chatId = q.message.chat.id;
        const messageId = q.message.message_id;
        const user = q.from;
        const action = q.data;
        const now = new Date().toLocaleString();

        let text = "";

        if (action === "trade_success") {
            text = `✔ *交易成功*\n操作者: *${user.first_name}*\n用户ID: *${user.id}*\n时间: ${now}`;
        }

        if (action === "trade_cancel") {
            text = `✖ *交易取消*\n操作者: *${user.first_name}*\n用户ID: *${user.id}*\n时间: ${now}`;
        }

        // 修改原消息（按钮会消失）
        await axios.post(`${API}/editMessageText`, {
            chat_id: chatId,
            message_id: messageId,
            text,
            parse_mode: "Markdown"
        });

        return res.sendStatus(200);
    }

    res.sendStatus(200);
});

export default router;
