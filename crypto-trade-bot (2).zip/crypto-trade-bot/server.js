// server.js
import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import bot from "./bot.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

app.use(express.static("public"));
app.use("/webhook", bot);

app.get("/", (req, res) => {
    res.send("Webhook test server running");
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log("SERVER RUNNING ON PORT", PORT));
