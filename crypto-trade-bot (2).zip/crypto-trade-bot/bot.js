// bot.js
import express from "express";
import axios from "axios";

const TOKEN = process.env.BOT_TOKEN;
const API = `https://api.telegram.org/bot${TOKEN}`;

const app = express();
app.use(express.json());

// Webhook 接收
app.post("/webhook", async (req, res) => {
    console.log("Webhook received:", JSON.stringify(req.body, null, 2));

    const update = req.body;

    // ==== 按钮点击处理 ====
    if (update.callback_query) {
        const query = update.callback_query;
        const user = query.from;
        const chatId = query.message.chat.id;
        const messageId = query.message.message_id;

        const action = query.data;
        const now = new Date().toLocaleString();

        let text = "";
        if (action === "trade_success") {
            text = `✔ *交易已确认*\n操作者: *${user.first_name}*\n用户ID: *${user.id}*\n时间: ${now}`;
        }
        if (action === "trade_cancel") {
            text = `✖ *交易已取消*\n操作者: *${user.first_name}*\n用户ID: *${user.id}*\n时间: ${now}`;
        }

        // 编辑原消息 → 按钮变成不可点击
        await axios.post(`${API}/editMessageText`, {
            chat_id: chatId,
            message_id: messageId,
            text,
            parse_mode: "Markdown"
        });

        return res.sendStatus(200);
    }

    res.sendStatus(200);
});

export default app;
